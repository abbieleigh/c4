/**
 * A statement that consists of a (parenthesized) conditional expression followed by
 * a statement to be executed while the conditional expression evaluates to true.
 */
public class WhileStmt extends BranchingStmt {

	protected Expr condition;
	protected Stmt body;
	
	/**
	 * Construct a <code>WhileStmt<code> object.
	 * @param condition the conditional expression
	 * @param body the statement to be executed if the conditional expression evaluates to true
	 */
	public WhileStmt(Expr condition, Stmt body) {
		this.condition = condition;
		this.body = body;
	}
	
	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	@Override
	public String toLLVM() {
		String whileLabel = NameAllocator.getLabelAllocator().next();
		String bodyLabel = NameAllocator.getLabelAllocator().next();
		String exitLabel = NameAllocator.getLabelAllocator().next();
		
		String llvm = generateUnconditionalBranchLlvm(whileLabel);
		llvm += generateLabelLlvm(whileLabel);
		llvm += generateConditionLlvm(bodyLabel, exitLabel, condition);
		llvm += generateBodyLlvm(bodyLabel, whileLabel, body);
		llvm += generateLabelLlvm(exitLabel);
		
		return llvm;
	}
}
