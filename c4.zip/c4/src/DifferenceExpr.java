/** An expression evaluated by subtracting one operand from another.
 */

public class DifferenceExpr extends BiExpr {

	/** Constructs a <code>DifferenceExpr</code> with a left and right operand.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 */
	public DifferenceExpr(Expr leftOp, Expr rightOp){
		super(leftOp, rightOp, "sub");
	}
}